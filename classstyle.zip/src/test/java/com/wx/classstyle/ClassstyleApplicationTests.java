package com.wx.classstyle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassstyleApplicationTests {

    @Test
    void contextLoads() {
    }

}
