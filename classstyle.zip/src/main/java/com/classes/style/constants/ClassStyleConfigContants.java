package com.classes.style.constants;

public class ClassStyleConfigContants {
    public static final String CLASS_SUMMARY_CODE = "class_summary";

    public static final String PASSWORD_PREFIX = "class_";

    public static final Integer PAGE_SIZE = 10;

}
