package com.classes.style.controller.home;

import com.alibaba.fastjson.JSONObject;
import com.classes.style.commom.Code;
import com.classes.style.commom.ResponseMsg;
import com.classes.style.service.ClassUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping(value = "/api")
public class ApiController {
    private static final Logger log = LoggerFactory.getLogger(ApiController.class);

    @Autowired
    private ClassUserService classUserService;

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseMsg register(@RequestBody JSONObject post) {
        try {
            Map<String, Object> res = classUserService.userRegister(post);
            int code = (int) res.get("code");
            if (code == 200) {
                return new ResponseMsg(Code.SUCCESS, res, "注册成功");
            } else {
                return new ResponseMsg(Code.FAIL, res, (String) res.get("msg"));
            }
        } catch (Exception e) {
            log.info("请求 register 接口出错 {}", e.getMessage());
            return new ResponseMsg(Code.FAIL, "", "注册失败");
        }
    }
}
