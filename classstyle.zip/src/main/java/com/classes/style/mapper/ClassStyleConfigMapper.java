package com.classes.style.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.classes.style.entity.ClassStyleConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ClassStyleConfigMapper extends BaseMapper<ClassStyleConfig> {
    ClassStyleConfig getClassStyleConfigByName(@Param("configName") String configName);

    void insertConfig(ClassStyleConfig classStyleConfig);

    void updateConfig(ClassStyleConfig classStyleConfig);
}
