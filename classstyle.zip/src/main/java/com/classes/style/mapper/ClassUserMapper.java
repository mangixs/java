package com.classes.style.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.classes.style.entity.ClassUser;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ClassUserMapper extends BaseMapper<ClassUser> {
}
