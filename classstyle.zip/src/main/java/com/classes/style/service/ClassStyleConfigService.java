package com.classes.style.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.classes.style.entity.ClassStyleConfig;

public interface ClassStyleConfigService extends IService<ClassStyleConfig> {
     ClassStyleConfig getClassConfigByName(String configName);

     void saveClassStyleConfigSummary(String summary);
}
