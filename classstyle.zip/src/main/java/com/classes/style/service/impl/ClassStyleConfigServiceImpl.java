package com.classes.style.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.classes.style.constants.ClassStyleConfigContants;
import com.classes.style.entity.ClassStyleConfig;
import com.classes.style.mapper.ClassStyleConfigMapper;
import com.classes.style.service.ClassStyleConfigService;
import com.classes.style.utils.DateUtil;
import com.classes.style.utils.HttpUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@Service
public class ClassStyleConfigServiceImpl extends ServiceImpl<ClassStyleConfigMapper, ClassStyleConfig>
        implements ClassStyleConfigService {
    @Resource
    private ClassStyleConfigMapper classStyleConfigMapper;

    @Override
    public ClassStyleConfig getClassConfigByName(String configName) {
        return classStyleConfigMapper.getClassStyleConfigByName(configName);
    }

    @Override
    @Transactional
    public void saveClassStyleConfigSummary(String summary) {
        ClassStyleConfig classStyleConfig = getClassConfigByName(ClassStyleConfigContants.CLASS_SUMMARY_CODE);
        if (classStyleConfig == null) {
            classStyleConfig = new ClassStyleConfig();
            classStyleConfig.setConfigDesc("班级简介");
            classStyleConfig.setConfigName(ClassStyleConfigContants.CLASS_SUMMARY_CODE);
            classStyleConfig.setConfigValue(summary);
            classStyleConfig.setIsValid(1);
            classStyleConfig.setOperator(HttpUtil.getOperator());
            classStyleConfig.setCreatedAt(DateUtil.getTimeNow());
            classStyleConfig.setUpdatedAt(DateUtil.getTimeNow());
            classStyleConfigMapper.insertConfig(classStyleConfig);
        } else {
            classStyleConfig.setConfigValue(summary);
            classStyleConfig.setOperator(HttpUtil.getOperator());
            classStyleConfig.setUpdatedAt(DateUtil.getTimeNow());
            classStyleConfigMapper.updateConfig(classStyleConfig);
        }
    }
}
