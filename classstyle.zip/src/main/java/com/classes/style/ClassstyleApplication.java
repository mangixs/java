package com.classes.style;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassstyleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClassstyleApplication.class, args);
    }

}
