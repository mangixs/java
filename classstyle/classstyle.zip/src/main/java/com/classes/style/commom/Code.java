package com.classes.style.commom;

public final class Code {

    public static final int SUCCESS = 200;

    public static final int FAIL = 500;

    public static final int UNKNOW = 0;

}
