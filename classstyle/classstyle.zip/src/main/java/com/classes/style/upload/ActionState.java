package com.classes.style.upload;

public enum ActionState {
	UNKNOW_ERROR
}
